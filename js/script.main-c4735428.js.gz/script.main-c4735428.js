// JavaScript includes
require('./_all_pages/menu');

// Any configuration and control can go here
console.log('Hello world from manifest.main');

